PROJECT: TCP Port Scanner
Name: [S.Thousiff Manash]

Description:
This project is a simple TCP port scanner developed using Python.
It scans a given IP address and port range to check whether ports are open or closed.

Tools Used:
- Python 3
- Socket Library
- Kali Linux
- Netcat (for testing)

How to Run:
1. Install Python 3
2. Open Command Prompt
3. Run: python port_scanner.py
4. Enter target IP
5. Enter port range