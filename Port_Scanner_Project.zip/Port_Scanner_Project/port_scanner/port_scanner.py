import socket

target=input("Enter target IP:")
port=int(input("Enter port:"))

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.settimeout(2)

result=s.connect_ex((target,port))

if result==0:
    print(f"port{port}is OPEN")
else:
     print(f"port{port}is CLOSED")


s.close()
